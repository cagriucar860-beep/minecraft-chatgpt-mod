package com.example.chatgptmod;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

public class AskCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("ask")
                .then(Commands.greedyString("question")
                .executes(ctx -> {
                    String question = ctx.getArgument("question", String.class);

                    String response = OpenAIClient.askGPT(question);

                    ctx.getSource().sendSuccess(
                        () -> Component.literal("GPT: " + response),
                        false
                    );

                    return 1;
                }))
        );
    }
}