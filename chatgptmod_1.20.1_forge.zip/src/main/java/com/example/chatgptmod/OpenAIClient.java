package com.example.chatgptmod;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class OpenAIClient {

    public static String askGPT(String prompt) {
        try {
            String apiKey = "PUT_YOUR_API_KEY_HERE";

            String json = """
            {
              "model": "gpt-4.1-mini",
              "messages": [
                {"role": "user", "content": "%s"}
              ]
            }
            """.formatted(prompt.replace(""", "\""));

            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.openai.com/v1/chat/completions"))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> response =
                client.send(request, HttpResponse.BodyHandlers.ofString());

            String body = response.body();

            int index = body.indexOf("content");
            if (index != -1) {
                int start = body.indexOf(""", index + 10) + 1;
                int end = body.indexOf(""", start);
                return body.substring(start, end);
            }

            return body;

        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}